package pbs.sme.survey.model;


public class Constants {
     public static final String VTYPE_DEF = "MT";
     public static final String ENV = "dev";
     public static final int APP_ID=1;
     public static final String THEME="THEME";
     public static final String PREF="MYPREF";
     public static final String LAST_IMPORT="LAST_IMPORT";
     public static final String LAST_ENTRY="LAST_ENTRY";
     public static final String LAST_SYNC="LAST_SYNC";
     public static final int PERMISSION_ALL_CODE=111;
     public static final int PERMISSION_LOCATION_CODE=990;
     public static final int PERMISSION_PHONE_CODE=880;
     public static final int PERMISSION_STORAGE_CODE=770;

     public static final String IS_LOGGED="IS_LOGGED";
     public static final String SHARED_DIRECTORY="/EXPORT/IACL";
     public static final String MAP_DIRECTORY="EXPORT/IAC/MAP";
     public static final String MAP_FILE_NAME = "my_map";
     public static final String MAP_FILE_EXTENSION = ".sqlite";
     public static final String UID="UID";
     public static final String SID="SID";
     public static final String ROLE="ROLE";
     public static final String USERNAME="USERNAME";
     public static final String ENUMERATOR="ENUMERATOR";
     public static final String LAST_LOGIN="LAST_LOGIN";
     public static final String SMS_CODE="SMS_CODE";
     public static final String SMS_EXPIRY="SMS_EXPIRY";

     public static final String SYNC_SERVICE_NOTIFICATION_CHANNEL_ID = "IAC_Sync_Notifications";
     public static final String SYNC_SERVICE_NOTIFICATION_CHANNEL_Name = "IAC Sync Notifications";
     public static final String HTTP_CALL_COUNT = "httpCount";
     public static final String HTTP_SUCCESS_COUNT = "httpSuccessCallCount";
     public static final String HTTP_FAILURE_COUNT = "httpFailedCallCount";
     public static final String HTTP_CALL_TIME = "httpCallTime";
     public static final String HTTP_CALL_SUCCESS_TIME = "successfulHttpCallTime";
     public static final String HTTP_CALL_FAILURE_TIME = "failedHttpCallTime";

     public static boolean isDevEnv(){
          return Constants.ENV == "dev" && pk.gov.pbs.utils.Constants.DEBUG_MODE;
     }

     public static class EXTRA {
          public static final String IDX_BLOCK = "model.assignment";
          public static final String IDX_HOUSE = "model.house";
          public static final String IDX_HOUSEHOLD = "model.household";

     }
}
